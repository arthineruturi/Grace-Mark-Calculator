<?php

//database_connection.php

$connect = new PDO("mysql:host=arthiazure.mysql.database.azure.com;dbname=gracemark", "arthisri", "A1@azure");

?>
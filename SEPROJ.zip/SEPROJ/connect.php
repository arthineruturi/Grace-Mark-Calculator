<?php
$host = "arthiazure.mysql.database.azure.com";
$user = "arthisri";
$password = 'A1@azure';
$db_name = "gracemark";
$con = mysqli_connect($host, $user, $password, $db_name);

?>
<?php
   define('DB_SERVER', 'arthiazure.mysql.database.azure.com');
   define('DB_USERNAME', 'arthisri');
   define('DB_PASSWORD', 'A1@azure');
   define('DB_DATABASE', 'testing');
   $conn = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>